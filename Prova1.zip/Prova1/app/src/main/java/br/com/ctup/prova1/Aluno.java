package br.com.ctup.prova1;

import java.io.Serializable;

/**
 * Created by Dev_Maker on 09/03/2016.
 */
public class Aluno implements Serializable{
    private int id;
    private String nome;
    private int nota;
    private String situacao;
    private int turma;

    public Aluno() {
    }

    public Aluno(String nome, int nota, String situacao, int turma) {
        this.nome = nome;
        this.nota = nota;
        this.situacao = situacao;
        this.turma = turma;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Aluno(String nome, int nota,int turma) {
        this.nome = nome;
        this.turma = turma;
        this.nota = nota;
        calculaSituacao(this.nota);
    }

    public void calculaSituacao(int nota){
        if(nota >= 70){
            this.situacao = "Aprovado";
        }if(nota >=40 && nota <=69){
            this.situacao = "Final";
        }else{
            this.situacao = "Reprovado";
        }
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
        if(nota >= 70){
            this.situacao = "Aprovado";
        }if(nota >=40 && nota <=69){
            this.situacao = "Final";
        }if(nota < 40){
            this.situacao = "Reprovado";
        }
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public int getTurma() {
        return turma;
    }

    public void setTurma(int turma) {
        this.turma = turma;
    }

    @Override
    public String toString() {
        return this.getNome();
    }
}
