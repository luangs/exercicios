package br.com.ctup.prova1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Dev_Maker on 09/03/2016.
 */
public class AlunoDAO {
    private SQLiteDatabase bd;

    public AlunoDAO(Context context) {
        BDCore auxBd = new BDCore(context);
        bd = auxBd.getWritableDatabase();
    }

    public void InsertAluno(Aluno aluno){
        ContentValues valores = new ContentValues();
        valores.put("nome",aluno.getNome());
        valores.put("nota",aluno.getNota());
        valores.put("situacao",aluno.getSituacao());
        valores.put("turma", aluno.getTurma());

        bd.insert("Alunos", null, valores);
    }


    public void EditarAluno(Aluno aluno){
        ContentValues valores = new ContentValues();
        valores.put("nome",aluno.getNome());
        valores.put("nota",aluno.getNota());
        valores.put("situacao",aluno.getSituacao());
        valores.put("turma",aluno.getTurma());

        bd.update("Alunos", valores, "_id = ?", new String[]{"" + aluno.getId()});

    }


    public void DeletarAluno(Aluno aluno){
        bd.delete("Alunos", "_id =" + aluno.getId(), null);
    }


    public List<Aluno> buscarAluno(int Turma){
        List<Aluno> list = new ArrayList<Aluno>();
        String[] colunas = new String[]{"_id", "nome", "nota","situacao","turma"};

        Cursor cursor = bd.query("Alunos", colunas, "turma = "+Turma, null, null, null, "nome ASC");

        if(cursor.getCount() > 0){
            cursor.moveToFirst();

            do{

                Aluno a = new Aluno();
                a.setId(cursor.getInt(0));
                a.setNome(cursor.getString(1));
                a.setNota(cursor.getInt(2));
                a.setSituacao(cursor.getString(3));
                a.setTurma(cursor.getInt(4));
                list.add(a);

            }while(cursor.moveToNext());
        }

        return(list);
    }



}
