package br.com.ctup.prova1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Dev_Maker on 09/03/2016.
 */
public class BDCore extends SQLiteOpenHelper{

    public static final String Nome_BD = "Alunos";
    private static final int VERSAO_BD = 2;
    private static final String SQLCreate = "create table Alunos (_id integer primary key autoincrement, nome text not null, nota integer not null, situacao text, turma integer not null);";

    public BDCore(Context context) {
        super(context, Nome_BD, null, VERSAO_BD);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQLCreate);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE Alunos");
        onCreate(db);
    }
}
