package br.com.ctup.prova1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;

public class BuscarAluno extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscar_aluno);

        final ListView listView  = (ListView) findViewById(R.id.alunosTurma);

        final AlunoDAO dao = new AlunoDAO(this);
        final Spinner turmas = (Spinner) findViewById(R.id.pesqTurma);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, new String[]{"Selecione uma turma", "Turma 1", "Turma 2"});
        turmas.setAdapter(adapter);

        turmas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                List values = dao.buscarAluno(turmas.getSelectedItemPosition());

                ArrayAdapter adapter2 = new ArrayAdapter(BuscarAluno.this, android.R.layout.simple_list_item_1, values);
                listView.setAdapter(adapter2);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(BuscarAluno.this, "Selecione uma turma", Toast.LENGTH_LONG).show();
            }
        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Aluno a = (Aluno) parent.getItemAtPosition(position);
                Toast.makeText(BuscarAluno.this,"Selecionado: "+a.getNome(), Toast.LENGTH_SHORT).show();
                Intent it = new Intent(BuscarAluno.this,FormAluno.class);
                it.putExtra("Aluno", a);
                startActivity(it);
                finish();
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_buscar_aluno, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
