package br.com.ctup.prova1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class FormAluno extends AppCompatActivity {

        Aluno aluno = new Aluno();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_aluno);

        Spinner turmas = (Spinner) findViewById(R.id.turma);
        EditText nome = (EditText) findViewById(R.id.nome);
        EditText nota = (EditText) findViewById(R.id.nota);
        Button btSalvar = (Button) findViewById(R.id.salvar);
        Button btDeletar = (Button) findViewById(R.id.deletar);
        Button btEditar = (Button) findViewById(R.id.editar);
        TextView situacao = (TextView) findViewById(R.id.situacao);


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line, new String[]{"Selecione uma turma","Turma 1", "Turma 2"});
        turmas.setAdapter(adapter);

        Intent intent = getIntent();
        if(intent != null){
            Bundle bundle = intent.getExtras();
                if(bundle != null){
                    Aluno a = (Aluno) intent.getSerializableExtra("Aluno");
                    aluno.setNome(a.getNome());
                    aluno.setTurma(a.getTurma());
//                    aluno.setSituacao(a.getSituacao());
                    aluno.setNota(a.getNota());
                    aluno.setId(a.getId());

                    nome.setText(a.getNome());
                    nota.setText("" + a.getNota());
                    turmas.setSelection(a.getTurma());
                    situacao.setText(aluno.getSituacao());

                    btSalvar.setVisibility(View.GONE);
                    btDeletar.setVisibility(View.VISIBLE);
                    btEditar.setVisibility(View.VISIBLE);

                }
        }

//        turmas.getSelectedItem()


    }

    public void cadastrarAluno(View view){
        AlunoDAO dao = new AlunoDAO(this);

        Spinner turma = (Spinner) findViewById(R.id.turma);
        EditText nome = (EditText) findViewById(R.id.nome);
        EditText nota = (EditText) findViewById(R.id.nota);

        aluno.setNome(nome.getText().toString());
        aluno.setNota(Integer.parseInt(nota.getText().toString()));
        aluno.setTurma(turma.getSelectedItemPosition());

        dao.InsertAluno(aluno);

        Toast.makeText(this,"Aluno inserido com sucesso", Toast.LENGTH_LONG).show();
        Intent it = new Intent(this,Dashboard.class);
        startActivity(it);
        finish();
    }

    public void EditarAluno(View view){
        AlunoDAO dao = new AlunoDAO(this);

        Spinner turma = (Spinner) findViewById(R.id.turma);
        EditText nome = (EditText) findViewById(R.id.nome);
        EditText nota = (EditText) findViewById(R.id.nota);

        aluno.setNome(nome.getText().toString());
        aluno.setNota(Integer.parseInt(nota.getText().toString()));
        aluno.setTurma(turma.getSelectedItemPosition());

        dao.EditarAluno(aluno);

        Toast.makeText(this,"Aluno "+ aluno.getNome() +" foi editado com sucesso", Toast.LENGTH_LONG).show();
        Intent it = new Intent(this,BuscarAluno.class);
        startActivity(it);
        finish();
    }

    public void sair(View view){
        Intent it = new Intent(this,Dashboard.class);
        startActivity(it);
        finish();
    }

    public void deletar(View view){
        AlunoDAO dao = new AlunoDAO(this);
            dao.DeletarAluno(aluno);
        Toast.makeText(this,"Aluno "+ aluno.getNome() +" foi deletado com sucesso", Toast.LENGTH_LONG).show();
        Intent it = new Intent(this,BuscarAluno.class);
        startActivity(it);
        finish();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_form_aluno, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
