package br.com.ctup.biscoitosorte;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> sortes;
    TextView sorteTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public void sorte(View view){
        sorteTxt = (TextView) findViewById(R.id.sorteDia);
        sortes = new ArrayList<>();
        sortes.add("A vida trará coisas boas se tiveres paciência.");
        sortes.add("Demonstre amor e alegria em todas as oportunidades e verás que a paz nasce dentro de você.");
        sortes.add("Não compense na ira o que lhe falta na razão.");
        sortes.add("Defeitos e virtudes são apenas dois lados da mesma moeda.");
        sortes.add("A maior de todas as torres começa no solo.");
        sortes.add("Não há que ser forte. Há que ser flexível.");
        sortes.add("Gente todo dia arruma os cabelos, por que não o coração?");
        sortes.add("Há três coisas que jamais voltam; a flecha lançada, a palavra\n" +
                "dita e a oportunidade perdida.");
        sortes.add("A juventude não é uma época da vida, é um estado de espírito.");
        sortes.add("Podemos escolher o que semear, mas somos obrigados a\n" +
                "colher o que plantamos.");
        sortes.add("Já tentei mudar, parar logo de fumar. Mas cigarros são poemas pra quem nunca sabe o que falar.");

        Collections.shuffle(sortes);
        sorteTxt.setText(sortes.get(0).toString());

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
