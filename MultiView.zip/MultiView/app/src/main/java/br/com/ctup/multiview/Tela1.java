package br.com.ctup.multiview;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class Tela1 extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela1);
    }

    public void onClick(View view) {
        EditText nome = (EditText) findViewById(R.id.nome);
        EditText idade = (EditText) findViewById(R.id.idade);
        EditText tel = (EditText) findViewById(R.id.tel);
        EditText login = (EditText) findViewById(R.id.login);
        EditText senha = (EditText) findViewById(R.id.senha);


        pessoa p = new pessoa();
        p.setNome(nome.getText().toString());
        p.setIdade(idade.getText().toString());
        p.setTelefone(tel.getText().toString());
        p.setLogin(login.getText().toString());
        p.setPass(senha.getText().toString());
        Intent it = new Intent(this, Tela2.class);
        it.putExtra("pessoa", p);
        startActivity(it);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tela1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
