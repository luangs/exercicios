package br.com.ctup.multiview;

import java.io.Serializable;

/**
 * Created by Dev_Maker on 26/02/2016.
 */
public class pessoa implements Serializable {
    private String nome;
    private String telefone;
    private String idade;
    private String login;
    private String pass;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}


