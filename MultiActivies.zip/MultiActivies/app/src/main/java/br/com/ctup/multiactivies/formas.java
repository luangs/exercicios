package br.com.ctup.multiactivies;

import java.io.Serializable;

/**
 * Created by Dev_Maker on 02/03/2016.
 */
public class formas implements Serializable {
    private String nome;
    private Integer contador;

    public formas(String nome) {
        this.contador = 0;
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getContador() {
        return contador;
    }

    public void setContador(Integer contador) {
        this.contador = contador;
    }

    public void addContador(){
        this.contador = this.contador + 1;
    }
}
