package br.com.ctup.multiactivies;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Dev_Maker on 02/03/2016.
 */
public class FormaAdapter extends BaseAdapter {

    public FormaAdapter(Context context, ArrayList<formas> objects) {
        this.objects = objects;
        this.context = context;
    }
    private ArrayList<formas> objects;
    private Context context;

    public View getView(int position, View convertView, ViewGroup parent){

        // assign the view we are converting to a local variable
        View v = convertView;

        // first check to see if the view is null. if so, we have to inflate it.
        // to inflate it basically means to render, or show, the view.
        ViewHolder vh;
        if (v == null) {
            vh = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.listfomas, null);
            vh.nome = (TextView) v.findViewById(R.id.nome);
            v.setTag(vh);
        }else{
            vh = (ViewHolder) convertView.getTag();
        }


        formas i = objects.get(position);

        vh.nome.setText(i.getNome());

        return v;

    }

    @Override
    public int getCount() {
        return objects.size();
    }

    @Override
    public Object getItem(int position) {
        return objects.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public class ViewHolder{
        public TextView nome;
    }


}
