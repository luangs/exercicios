package br.com.ctup.multiactivies;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class formacont extends Activity {

    formas forma;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formacont);

        TextView nome = (TextView) findViewById(R.id.nome);
        TextView contador = (TextView) findViewById(R.id.contador);

        Intent it = getIntent();
        if(it != null){
            forma = (formas) it.getSerializableExtra("forma");
            nome.setText(forma.getNome());
//            contador.setText(forma.getContador());
        }else{
            finish();
        }
    }

    Integer cnt = 0;
    public void somar(View view){
        TextView contador = (TextView) findViewById(R.id.contador);
            cnt++;
        contador.setText(cnt.toString());
    }

    public void sair(View view){
        Intent it = new Intent(this,MainActivity.class);
        startActivity(it);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_formacont, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
