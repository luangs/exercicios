package br.com.ctup.listtest;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Dev_Maker on 01/03/2016.
 */
public class DrinkAdapter extends BaseAdapter {

    private ArrayList<drinks> objects;
    private Context context;
    public DrinkAdapter(Context context, ArrayList<drinks> objects) {
        this.objects = objects;
        this.context = context;
    }

    public View getView(int position, View convertView, ViewGroup parent){

        // assign the view we are converting to a local variable
        View v = convertView;

        // first check to see if the view is null. if so, we have to inflate it.
        // to inflate it basically means to render, or show, the view.
        ViewHolder vh;
        if (v == null) {
             vh = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.item_drink, null);
            vh.nome = (TextView) v.findViewById(R.id.nome);
            v.setTag(vh);
        }else{
           vh = (ViewHolder) convertView.getTag();
        }

		/*
		 * Recall that the variable position is sent in as an argument to this method.
		 * The variable simply refers to the position of the current object in the list. (The ArrayAdapter
		 * iterates through the list we sent it)
		 *
		 * Therefore, i refers to the current Item object.
		 */
        drinks i = objects.get(position);

        vh.nome.setText(i.getNome());
        // the view must be returned to our activity
        return v;

    }

    @Override
    public int getCount() {
        return objects.size();
    }

    @Override
    public drinks getItem(int position) {
        return objects.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder{
        public TextView nome;
    }
}
