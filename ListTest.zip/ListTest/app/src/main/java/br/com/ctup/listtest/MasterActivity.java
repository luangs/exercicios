package br.com.ctup.listtest;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MasterActivity extends Activity {
    ArrayList<drinks> lista = new ArrayList<>();
    DrinkAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_master);
        ListView lv = (ListView) findViewById(R.id.listaDrinks);
        adapter = new DrinkAdapter(this, lista);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                drinks c = (drinks) parent.getItemAtPosition(position);
                Toast.makeText(MasterActivity.this,"Selecionado: "+c.getNome(), Toast.LENGTH_SHORT).show();
                Intent it = new Intent(MasterActivity.this,drinks_info.class);
                it.putExtra("drink", c);
                startActivity(it);
                finish();
            }
        });

//        String[] Itens = new String[]{"Item 1", "Item 2", "Item 3"};
//        ArrayAdapter<String> array;
//        array = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,Itens);
//        setListAdapter(array);
    }

    @Override
    protected void onStart() {
        super.onStart();
        lista.clear();
        drinks d;
        drinks d2;
        lista.add(new drinks("Drink dos deuses", "1 vidro(100 ML) de leite de coco; \n 1 Copo (100ML) de suco de Maracujá \n 1 Copo de groselha \n 1 lata de leite condensado \n  Gelo picado", "Bater os primeiros 5 ingredientes no liquidificador e depois acrescentar gelo ao servir."));
        lista.add(new drinks("Batida de sonho de valsa", "3 bombons sonho de valsa \n 1 lata de leite condensado \n 1/2 garrafa de pinga \n 1 latinha de guaraná", "1 bater tudo no liquidificador \n 2 Acrescentar os chocolates \n 3 Servir gelado."));
        adapter.notifyDataSetChanged();
    }

    //    @Override
//    public void onListItemClick(ListView l, View v, int posicao, long id) {
//        super.onListItemClick(l, v, posicao, id);
//
//
//////        pega o item da posicao
////        Object obj = this.getListAdapter().getItem(posicao);
////        String item = obj.toString();
////
////        Toast.makeText(this,"Selecionado: "+item, Toast.LENGTH_SHORT).show();
//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_master, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
