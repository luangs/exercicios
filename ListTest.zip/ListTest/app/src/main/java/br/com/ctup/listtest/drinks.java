package br.com.ctup.listtest;

import java.io.Serializable;

/**
 * Created by Dev_Maker on 29/02/2016.
 */
public class drinks implements Serializable {
     private String nome;
    private String ingredientes;
    private String preparo;

    public drinks(String nome, String ingredientes, String preparo) {
        this.nome = nome;
        this.ingredientes = ingredientes;
        this.preparo = preparo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    public String getPreparo() {
        return preparo;
    }

    public void setPreparo(String preparo) {
        this.preparo = preparo;
    }
}
